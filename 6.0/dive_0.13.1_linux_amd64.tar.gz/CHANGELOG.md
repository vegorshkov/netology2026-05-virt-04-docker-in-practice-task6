# v0.13.1

### Bug Fixes

- Fix layer selection to select only one layer at a time [[#585](https://github.com/wagoodman/dive/pull/585) @wagoodman]
- Publish dive to ghcr.io [[#573](https://github.com/wagoodman/dive/issues/573) [#577](https://github.com/wagoodman/dive/pull/577) @wagoodman]

**[(Full Changelog)](https://github.com/wagoodman/dive/compare/v0.13.0...v0.13.1)**
